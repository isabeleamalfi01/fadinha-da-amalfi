
let fada; // Objeto para representar a fada

function setup() {
  createCanvas(600, 400); // Cria o canvas
  fada = new Fada(); // Inicializa a fada
}

function draw() {
  background(200, 220, 255); // Fundo azul claro (céu)
  
  fada.update(); // Atualiza a posição da fada
  fada.show(); // Desenha a fada
}

// Classe Fada
class Fada {
  constructor() {
    this.x = width / 2;
    this.y = height / 2;
    this.size = 50;
    this.speedX = random(1, 3);
    this.speedY = random(1, 3);
    this.angle = 0;
    this.wingSpeed = 0.1;
  }

  update() {
    // Movimento suave para a fada
    this.x += this.speedX;
    this.y += this.speedY;
    
    // Caso a fada atinja a borda da tela, ela muda de direção
    if (this.x > width || this.x < 0) {
      this.speedX *= -1;
    }
    if (this.y > height || this.y < 0) {
      this.speedY *= -1;
    }
  }

  show() {
    // Corpo da fada (um círculo simples)
    fill(255, 180, 200);
    noStroke();
    ellipse(this.x, this.y, this.size);
    
    // Asinhas da fada (simples triângulos que "batem")
    push();
    translate(this.x, this.y);
    rotate(sin(this.angle) * 0.2); // Movimento da asa
    
    // Asa esquerda
    fill(200, 100, 255, 150);
    triangle(-this.size / 2, -this.size / 2, -this.size, -this.size - 20, -this.size / 2, -this.size - 40);
    
    // Asa direita
    rotate(PI);
    fill(200, 100, 255, 150);
    triangle(this.size / 2, -this.size / 2, this.size, -this.size - 20, this.size / 2, -this.size - 40);
    
    pop();
    
    // Atualiza o movimento das asas
    this.angle += this.wingSpeed;
  }
}
